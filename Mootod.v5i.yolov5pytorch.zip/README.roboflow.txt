
Mootod - v5 2021-09-25 11:36am
==============================

This dataset was exported via roboflow.ai on September 25, 2021 at 4:39 AM GMT

It includes 96 images.
Moo are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip


