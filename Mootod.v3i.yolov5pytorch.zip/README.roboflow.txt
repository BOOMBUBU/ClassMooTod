
Mootod - v3 2021-09-25 11:25am
==============================

This dataset was exported via roboflow.ai on September 25, 2021 at 4:28 AM GMT

It includes 38 images.
Moo are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Grayscale (CRT phosphor)

The following augmentation was applied to create 3 versions of each source image:
* Random brigthness adjustment of between -25 and +25 percent


